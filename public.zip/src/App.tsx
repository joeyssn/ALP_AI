import Home from "./pages/home"

function App() {
  return (
    <div className="font-sans">
      <Home/>
    </div>
  )
}

export default App
